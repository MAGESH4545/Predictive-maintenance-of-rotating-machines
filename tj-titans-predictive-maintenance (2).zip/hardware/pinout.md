# Pinout and Wiring (ESP32 DevKit)

Matches `firmware/predictive_maintenance/predictive_maintenance.ino`.

## Power input: 5V supply

| From | To | Notes |
|---|---|---|
| 5V supply (+) | ESP32 **VIN** pin | 5V input; powers the board and the LM35D |
| 5V supply (-) | ESP32 **GND** | Common ground for all parts |

- The 3V3 pin on the ESP32 powers the MPU6050.
- Use a stable 5V supply (USB adapter or buck converter output). Do not feed more than 5V.
- Do not power the board from VIN and USB at the same time unless your board has protection for it.

## Pin table

| Component | Component pin | ESP32 pin | Notes |
|---|---|---|---|
| **MPU6050** | VCC | 3V3 | Power |
| | GND | GND | |
| | SDA | **GPIO 21** | I2C data |
| | SCL | **GPIO 22** | I2C clock |
| **LM35D** (temperature) | +Vs (pin 1) | VIN (5V) | LM35D needs 4V or more |
| | Vout (pin 2) | **GPIO 34** | ADC input, 10 mV per degree C |
| | GND (pin 3) | GND | |
| **Green LED** | Anode (+), via 220 ohm | **GPIO 25** | Normal |
| | Cathode (-) | GND | |
| **Yellow LED** | Anode (+), via 220 ohm | **GPIO 26** | Warning |
| | Cathode (-) | GND | |
| **Red LED** | Anode (+), via 220 ohm | **GPIO 27** | Critical / sensor error |
| | Cathode (-) | GND | |

## Wiring diagram

```
                 ESP32 DevKit
              +-----------------+
   5V supply  |                 |
   (+) -------| VIN (5V in)     |
   (-) -------| GND             |
              |                 |
   MPU6050    |                 |
   VCC  ------| 3V3             |
   GND  ------| GND             |
   SDA  ------| GPIO 21         |
   SCL  ------| GPIO 22         |
              |                 |
   LM35D      |                 |
   +Vs  ------| VIN (5V)        |
   Vout ------| GPIO 34 (ADC)   |
   GND  ------| GND             |
              |                 |
   Green  -[220R]-| GPIO 25     |
   Yellow -[220R]-| GPIO 26     |
   Red    -[220R]-| GPIO 27     |
   LED cathodes ----| GND      |
              +-----------------+
```

## LED meaning

| LED | Status |
|---|---|
| Green | NORMAL |
| Yellow | WARNING |
| Red | CRITICAL, or sensor error (MPU6050 missing / LM35D reading out of range) |

## Thresholds in the code

| Reading | Warning | Critical |
|---|---|---|
| Temperature (LM35D) | 40 C or more | 50 C or more |
| Vibration indicator | 1.5 m/s^2 or more | 3.0 m/s^2 or more |

The vibration indicator is |acceleration magnitude - 9.81|. Change the numbers in `loop()` to suit your motor.

## Tips
- Keep the LM35D output wire short, or add a 0.1 uF capacitor from Vout to GND if readings jump.
- GPIO 34 is input-only, which is fine for the ADC.
- If the red LED lights at start, the MPU6050 was not found. Check SDA/SCL and power.
