#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <math.h>

#define TEMP_PIN 34
#define GREEN_LED 25
#define YELLOW_LED 26
#define RED_LED 27

Adafruit_MPU6050 mpu;

void setLEDs(bool green, bool yellow, bool red) {
  digitalWrite(GREEN_LED, green);
  digitalWrite(YELLOW_LED, yellow);
  digitalWrite(RED_LED, red);
}

float readTemperature() {
  int milliVolts = analogReadMilliVolts(TEMP_PIN);
  float voltage = milliVolts / 1000.0;
  return voltage * 100.0;
}

void setup() {
  Serial.begin(115200);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);

  analogReadResolution(12);
  analogSetPinAttenuation(TEMP_PIN, ADC_11db);

  Wire.begin(21, 22);
  setLEDs(false, false, false);

  if (!mpu.begin()) {
    Serial.println("ERROR: MPU6050 not detected!");
    setLEDs(false, false, true);

    while (true) {
      delay(100);
    }
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  Serial.println("Predictive Maintenance Started");
}

void loop() {
  sensors_event_t accel, gyro, sensorTemp;
  mpu.getEvent(&accel, &gyro, &sensorTemp);

  float x = accel.acceleration.x;
  float y = accel.acceleration.y;
  float z = accel.acceleration.z;

  float magnitude = sqrt(x * x + y * y + z * z);
  float vibration = fabs(magnitude - 9.81);

  float temperature = readTemperature();

  bool tempValid = temperature >= 0.0 && temperature <= 125.0;

  bool critical =
      (tempValid && temperature >= 50.0) ||
      vibration >= 3.0;

  bool warning =
      (tempValid && temperature >= 40.0) ||
      vibration >= 1.5;

  Serial.println("----------------------------");

  Serial.print("Temperature: ");
  Serial.print(temperature, 1);
  Serial.println(" C");

  Serial.print("Vibration indicator: ");
  Serial.print(vibration, 2);
  Serial.println(" m/s^2");

  if (!tempValid) {
    setLEDs(false, false, true);
    Serial.println("STATUS: CHECK LM35D SENSOR");
  }
  else if (critical) {
    setLEDs(false, false, true);
    Serial.println("STATUS: CRITICAL");
  }
  else if (warning) {
    setLEDs(false, true, false);
    Serial.println("STATUS: WARNING");
  }
  else {
    setLEDs(true, false, false);
    Serial.println("STATUS: NORMAL");
  }

  delay(1000);
}
